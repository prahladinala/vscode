# PR Dark Theme 01

## About the extension :
This Theme is designed to the late night developers


### Developer: PRahlad Inala
**Enjoy!**
