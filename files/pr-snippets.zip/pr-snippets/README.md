# pr-snippets README

# PR Snippets
PR Snippets is designed for a fast-track developers

## Tutorial
1. For Html snippet !prh
2. For Html and Css snippet !prhc
3. For Html, Css and JavaScript snippet !prhcj
4. For Html, Css, JavaScript and Bootstrap snippet !prhcjb
5. For Html and Bootstrap snippet !prhbt


**Enjoy!**
